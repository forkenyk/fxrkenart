const CONTOUR =
  "M 639.0 56.0 L 670.0 55.0 L 671.0 101.0 L 767.0 93.0 L 806.0 98.0 L 852.0 112.0 L 870.0 126.0 L 875.0 161.0 L 907.0 172.0 L 952.0 176.0 L 1010.0 157.0 L 1036.0 157.0 L 1034.0 188.0 L 1012.0 239.0 L 1012.0 263.0 L 1075.0 307.0 L 1127.0 324.0 L 1127.0 347.0 L 1085.0 390.0 L 1085.0 407.0 L 1097.0 429.0 L 1108.0 465.0 L 1111.0 507.0 L 1074.0 520.0 L 1073.0 558.0 L 1033.0 566.0 L 1026.0 593.0 L 1013.0 667.0 L 1049.0 687.0 L 1049.0 706.0 L 1027.0 750.0 L 1027.0 821.0 L 1016.0 864.0 L 1001.0 895.0 L 961.0 933.0 L 928.0 945.0 L 898.0 1008.0 L 877.0 1037.0 L 842.0 1072.0 L 732.0 1156.0 L 702.0 1173.0 L 671.0 1179.0 L 607.0 1172.0 L 544.0 1136.0 L 465.0 1074.0 L 405.0 1019.0 L 371.0 973.0 L 349.0 914.0 L 280.0 916.0 L 272.0 888.0 L 240.0 864.0 L 221.0 840.0 L 202.0 782.0 L 201.0 737.0 L 213.0 703.0 L 226.0 688.0 L 261.0 670.0 L 261.0 656.0 L 235.0 587.0 L 222.0 507.0 L 183.0 497.0 L 181.0 492.0 L 178.0 428.0 L 197.0 386.0 L 197.0 370.0 L 196.0 362.0 L 177.0 344.0 L 161.0 320.0 L 161.0 299.0 L 220.0 281.0 L 242.0 266.0 L 237.0 207.0 L 246.0 202.0 L 299.0 185.0 L 372.0 186.0 L 386.0 156.0 L 406.0 131.0 L 437.0 105.0 L 465.0 90.0 L 481.0 90.0 L 497.0 110.0 L 512.0 110.0 L 566.0 78.0 Z";

export function LogoReveal() {
  return (
    <svg
      className="fx-logo-svg"
      viewBox="0 0 1254 1254"
      role="presentation"
      aria-hidden="true"
    >
      <defs>
        <path id="fxrken-contour" d={CONTOUR} />

        <mask
          id="fxrken-progress-mask"
          x="0"
          y="0"
          width="1254"
          height="1254"
          maskUnits="userSpaceOnUse"
          maskContentUnits="userSpaceOnUse"
          style={{ maskType: "alpha" }}
        >
          <path
            className="fx-logo-svg__reveal"
            d={CONTOUR}
            fill="none"
            stroke="#fff"
          />
        </mask>

        <filter id="fxrken-trail-glow" x="-45%" y="-45%" width="190%" height="190%">
          <feGaussianBlur stdDeviation="10" />
        </filter>
        <filter id="fxrken-head-glow" x="-100%" y="-100%" width="300%" height="300%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="18" result="wide" />
          <feGaussianBlur in="SourceGraphic" stdDeviation="5" result="tight" />
          <feMerge>
            <feMergeNode in="wide" />
            <feMergeNode in="tight" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      <image
        href="/fxrken-logo-3d.png?v=7"
        width="1254"
        height="1254"
        preserveAspectRatio="xMidYMid meet"
        mask="url(#fxrken-progress-mask)"
      />

      <use
        href="#fxrken-contour"
        className="fx-logo-svg__trail"
        fill="none"
        stroke="#fff"
        filter="url(#fxrken-trail-glow)"
      />
      <use
        href="#fxrken-contour"
        className="fx-logo-svg__core"
        fill="none"
        stroke="#fff"
      />
      <use
        href="#fxrken-contour"
        className="fx-logo-svg__head"
        fill="none"
        stroke="#fff"
        filter="url(#fxrken-head-glow)"
      />
    </svg>
  );
}
